package com.example.kafecorluandroid;

public class KafeMenu {
	int _id;
	String _turu;
	String _isim;
	String _fiyat;
	
	public KafeMenu(){
		
	}
	
	public KafeMenu(int id,String turu,String isim,String fiyat){
		this._id=id;
		this._turu=turu;
		this._isim=isim;
		this._fiyat=fiyat;
	}
	
	
		
	
	//Menu ID
		public int getmenuID(){
			return this._id;
		}
		
		public void setmenuID(int menuID){
			this._id=menuID;
		}
		
	public String getTuru(){
		return this._turu;
	}
	
	public void setTuru(String turu){
		this._turu=turu;
	}
	
	public String getIsim(){
		return this._isim;
	}
	
	public void setIsim(String isim){
		this._isim=isim;
	}
	
	public String getFiyat(){
		return this._fiyat;
	}
	
	public void setFiyat(String fiyat){
		this._fiyat=fiyat;
	}
	
	
	
	
}
