package com.example.kafecorluandroid;

public class Masalar {
	int _masaID;
	int _siparis;
	int _siparisKac;
	int _aktif;
	
	public Masalar(){
		
	}
	
	public Masalar(int masaID,int siparis,int kac,int aktif){
		this._masaID=masaID;
		this._siparis=siparis;
		this._siparisKac=kac;
		this._aktif=aktif;
	}
	//Masa ID
	public int getMasaID(){
		return this._masaID;
	}
	
	public void setMasaID(int masaID){
		this._masaID=masaID;
	}
	//Siparsi
	public int getSiparis(){
		return this._siparis;
	}
	
	public void setSiparisID(int siparis){
		this._siparis=siparis;
	}
	
	//kac tane
	public int getSiparisKac(){
		return this._siparisKac;
	}
	
	public void setSiparisKac(int kac){
		this._siparisKac=kac;
	}
	
	//Aktif Pasif
		public int getAktif(){
			return this._aktif;
		}
		
		public void setAktif(int durum){
			this._aktif=durum;
		}
	
}
