package com.example.kafecorluandroid;

import java.util.ArrayList;
import java.util.List;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper{
	// Database Version
		private static final int DATABASE_VERSION = 1;

		// Database Name
		private static final String DATABASE_NAME = "VERILER";
		
		//Tables
		private static final String TABLE_MASALAR = "MASALAR";
		private static final String TABLE_MENU = "MENU";
		
		//Kolonlar
		private static final String MASA_ID="MASA_ID";
		private static final String SIPARIS_INT="SIPARIS_INT";
		private static final String SIPARIS_KAC="SIPARIS_KAC";
		private static final String AKTIFMI = "AKTIFMI";
		
		private static final String MENU_ID="MENU_ID";
		private static final String MENU_TURU="MENU_TURU";
		private static final String MENU_ISIM="MENU_ISIM";
		private static final String FIYAT="FIYAT";
		
		public DatabaseHandler(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
	
		/*
	int _id;
	String _turu;
	String _isim;
	String _fiyat;
		*/
		@Override
		public void onCreate(SQLiteDatabase db) {
			//Masalar
			String CREATE_MASA_TABLE = "CREATE TABLE "+TABLE_MASALAR+ "("
					+ " MASA_ID INT,"
					+ " SIPARIS INT,"
					+ " SIPARIS_KAC  INT,"
					+ " AKTIFMI INT)";
			db.execSQL(CREATE_MASA_TABLE);
			
			String CREATE_MENU_TABLE = "CREATE TABLE "+TABLE_MENU+ "("
					+ " MENU_ID INT,"
					+ " MENU_TURU TEXT,"
					+ " MENU_ISIM TEXT,"
					+ " FIYAT TEXT)";
			db.execSQL(CREATE_MENU_TABLE);
		}
		
		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// Drop older table if existed
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_MASALAR);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_MENU);
			
			// Create tables again
			onCreate(db);
		}
		
		//CRUD
		
		// Adding new menu
		void addMenu(KafeMenu menu) {
			SQLiteDatabase db = this.getWritableDatabase();
			ContentValues values = new ContentValues();
			values.put(MENU_ID,menu.getmenuID() ); // Menu ID
			values.put(MENU_TURU,menu.getTuru() ); // Menu T�r�
			values.put(MENU_ISIM,menu.getIsim() ); // Menu isim
			values.put(FIYAT,menu.getFiyat() ); // Menu fiyat
			// Inserting Row
			db.insert(TABLE_MENU, null, values);
			db.close(); // Closing database connection
		}
		
		
		//Add masa siparis
		void addMasaSiparis(Masalar masa){
			SQLiteDatabase db = this.getWritableDatabase();
			ContentValues values = new ContentValues();
			values.put(MASA_ID, masa.getMasaID());
			values.put(SIPARIS_INT, masa.getSiparis());
			values.put(SIPARIS_KAC,masa.getSiparisKac());
			values.put(AKTIFMI, masa.getAktif());
			// Inserting Row
			db.insert(TABLE_MASALAR, null, values);
			db.close(); // Closing database connection
		}
		
		
		//Menu listesi
		public List<KafeMenu> getMenu(){
			List<KafeMenu> listMenu=new ArrayList<KafeMenu>();
			// Select All Query
			String selectQuery = "SELECT  * FROM " + TABLE_MENU +" ORDER BY "+MENU_TURU;

			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(selectQuery, null);

			// looping through all rows and adding to list
			if (cursor.moveToFirst()) {
				do {
					KafeMenu menu = new KafeMenu();
					menu.setmenuID(Integer.parseInt(cursor.getString(0)));
					menu.setTuru(cursor.getString(1));
					menu.setIsim(cursor.getString(2));
					menu.setFiyat(cursor.getString(3));
					listMenu.add(menu);
				} while (cursor.moveToNext());
			}
			cursor.close();
			db.close();
			// return contact list
			return listMenu;
			
		}
		
		//Menu kac tane
		public int menuKacTane(){
			String query="SELECT COUNT(*) FROM "+ TABLE_MENU;
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(query, null);
			int kacTane=0;
			if (cursor.moveToFirst()) kacTane=Integer.parseInt(cursor.getString(0));
			return kacTane;
		}
		
		//Masa siparisi
		public List<Masalar> getMasaSipari(int hangiMasa){
			List<Masalar> masaHesap=new ArrayList<Masalar>();
			String selectQuery=	"SELECT * FROM "+TABLE_MASALAR+" WHERE "+MASA_ID+" ="
					+Integer.toString(hangiMasa)+" AND AKTIFMI=1";
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.rawQuery(selectQuery, null);
			// looping through all rows and adding to list
						if (cursor.moveToFirst()) {
							do {
								Masalar siparis=new Masalar();
								siparis.setMasaID(Integer.parseInt(cursor.getString(0)));
								siparis.setSiparisID(Integer.parseInt(cursor.getString(1)));
								siparis.setSiparisKac(Integer.parseInt(cursor.getString(2)));
								siparis.setAktif(Integer.parseInt(cursor.getString(3)));
								masaHesap.add(siparis);
							} while (cursor.moveToNext());
						}
			cursor.close();
			db.close();
			return masaHesap;
		}
		
		
}
