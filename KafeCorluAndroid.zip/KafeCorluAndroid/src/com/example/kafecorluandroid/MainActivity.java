package com.example.kafecorluandroid;

import java.util.ArrayList;
import java.util.List;


import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity {
	ListView menuListesi;
	final ArrayList<String> arr0=new ArrayList<String>();
    ArrayAdapter<String> adapter;
    List<KafeMenu> menuList;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        menuListesi=(ListView)findViewById(R.id.menuList);
        
      //List view
        //arr0.add("Elma ");
        //arr0.add("Portakal ");
        arr0.add("Elma "); 
        arr0.add("Portakal ");
        arr0.add("Mandalina ");
        arr0.add("Vişne ");
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,android.R.id.text1,arr0);
        menuListesi.setAdapter(adapter);
        /*This is for refreshing 
        	adapter.clear();
			adapter.add("Nokia");
			adapter.add("Palm");
			adapter.add("HP");
        */
        menuListesi.setOnItemClickListener(new OnItemClickListener(){
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				Log.d("onClick ",Integer.toString(arg2)+" and "+arg3);
				gosterSiparisDialog(arg2);
			}
        	
        });
        
        olusturYeniMenu();
        listeyiGoster();
    }
    
    private void gosterSiparisDialog(int hangisi){
    	
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	AlertDialog dialog;
    	builder.setTitle("Sipariş");
		builder.setMessage("Miktar.");
		builder.setPositiveButton("Tamam", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				//uploadToServer();
			}    				
		});    		
		builder.setNegativeButton("iptal", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				
			}    				
		});
		dialog= builder.create();
	 	dialog.show();
    	
    	
    }
    

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    void listeyiGoster(){
    	adapter.clear();
    	DatabaseHandler db = new DatabaseHandler(this);
    	menuList=db.getMenu();
    	for(KafeMenu cn:menuList){
    		adapter.add(cn.getIsim()+" .. "+cn.getFiyat());
    	}
    	
    }
    
    
    
    void olusturYeniMenu(){
    	
    	DatabaseHandler db = new DatabaseHandler(this);
    	int kacTane=db.menuKacTane();
    	Log.d("kac tane ",Integer.toString(kacTane));
    	
    	if(kacTane==0) {
    		db.addMenu(new KafeMenu(1,"içecek","Kafe Latte","6.50"));
    		db.addMenu(new KafeMenu(2,"içecek","Çay","2.50"));
    		db.addMenu(new KafeMenu(3,"içecek","Capucino","6.50"));
    		db.addMenu(new KafeMenu(4,"içecek","Expresson","6.50"));
    		db.addMenu(new KafeMenu(5,"içecek","Mırra","6.50"));
    		db.addMenu(new KafeMenu(6,"içecek","Türk Kahvesi","6.50"));
    	}
    	kacTane=db.menuKacTane();
    	
    	Log.d("kac tane ",Integer.toString(kacTane));
    	
    	
    	
    	
    	
    }
}
