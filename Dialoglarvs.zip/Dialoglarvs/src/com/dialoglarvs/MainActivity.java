package com.dialoglarvs;

import java.util.Calendar;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.text.Editable;
import android.text.method.DigitsKeyListener;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	TextView tarih,help,arama,takim;
	
	int pYear,pMonth,pDay;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tarih=(TextView)findViewById(R.id.tarih);
        help=(TextView)findViewById(R.id.help);
        arama=(TextView)findViewById(R.id.arama);
        takim=(TextView)findViewById(R.id.tutulanTakim);
        
        
        takim.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				listeGoster();
				
			}
		});
        
        
        tarih.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				tarihSecDialog();
				
			}
		});
        
        help.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				gosterHelp();
				
			}
		});
        
        arama.setOnClickListener(new View.OnClickListener() {
			
   			@Override
   			public void onClick(View v) {
   				// TODO Auto-generated method stub
   				gosterArama();
   				
   			}
   		});
        
    }
    
    
    private void listeGoster(){
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	 	AlertDialog dialog;
	 	final String[] liste={"Fenerbahçe","Galatasaray","Beşiktaş","Kayserispor","Sivasspor","Bursaspor","İstanbul Belediye"};
		builder.setTitle("Desteklediğiniz Takım?");
		builder.setItems(liste, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int which) {
				// TODO Auto-generated method stub
				takim.setText(liste[which]);
			}
		});
		dialog= builder.create();
	 	dialog.show();
	 	
    }
    
    private void gosterArama(){
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	 	AlertDialog dialog;
	 	builder.setTitle("Arama");
		builder.setMessage("Neyi aramak istersiniz");
	 	final EditText input=new EditText(this);
	 	input.setKeyListener(new DigitsKeyListener(true,true));
		builder.setView(input);
	 	
    	builder.setPositiveButton("Arama", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
			Editable value = input.getText();
			arama.setText(value.toString());
			 // Do something with value!
				
			 }
			});

		builder.setNegativeButton("iptal", new DialogInterface.OnClickListener() {
			 public void onClick(DialogInterface dialog, int whichButton) {
			     // Canceled.
			}
			});
		
		//return builder.create();
		dialog=builder.create();
		dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
	 	
		dialog.show();
    }
    
    
    
    private void gosterHelp(){
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	AlertDialog dialog;
    	builder.setTitle("Yardım");
		builder.setMessage("Tarih yazısına dokunarak seçiminizi yapın.");
		builder.setPositiveButton("Tamam", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				
			}
	    
		});

		builder.setNegativeButton("Tarih Seç", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int whichButton) {
				tarihSecDialog();
			}    				
		});
		
		dialog= builder.create();
		dialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    @Override
    public void onResume() {
    	super.onResume();
    	final Calendar c=Calendar.getInstance();
        
    	pYear=c.get(Calendar.YEAR);
        pMonth=c.get(Calendar.MONTH);
        pDay=c.get(Calendar.DAY_OF_MONTH);
        updateTarih();
    }
    
    private void tarihSecDialog(){
    	//AlertDialog.Builder builder = new AlertDialog.Builder(this);
    	AlertDialog dialog;
    	dialog=new DatePickerDialog(this,mDateSetListener,pYear,pMonth,pDay);
	 	dialog.show();
    }
    
    private DatePickerDialog.OnDateSetListener mDateSetListener=new DatePickerDialog.OnDateSetListener() {	
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
			// TODO Auto-generated method stub
			pYear=year;
			pMonth=monthOfYear+1;
			pDay=dayOfMonth;
			updateTarih();
			
		}
	};
	
	private void updateTarih(){
		String myTarih;
		myTarih=Integer.toString(pDay)+"."+Integer.toString(pMonth)+"."+Integer.toString(pYear);
		tarih.setText(myTarih);
	}
    
}
