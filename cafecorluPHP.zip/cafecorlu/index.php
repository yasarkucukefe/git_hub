<?php
$VERSION="?v=0"; //21.05.2012

?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Cafe Çorlu | Sipariş Takip</title>
        <link rel="stylesheet" type="text/css" href="res/main.css<?php echo $VERSION; ?>">
        
        <script type="text/javascript" src="js/jquery.js<?php echo $VERSION; ?>"></script>
        <script type="text/javascript" src="js/jqueryTimer.js<?php echo $VERSION; ?>"></script>
        <script type="text/javascript" src="js/siparis.js<?php echo $VERSION; ?>"></script>
        
        
    </head>
    <body>
        <h1>Cafe Çorlu - Sipariş Takip</h1>
        <div id="zaman">now</div><hr>
        
            <?php include 'content/divMasa.php' ?>
       
        <div style="clear"></div>
       
        
        <div id="siparisler">Liste</div>
        <div id="adisyon">Adisyon</div>
        
    </body>
</html>
