$(document).ready(function(){
    $('.masa').click(function(){
        var hangiMasa=$(this).attr('id');
        showAdisyon(hangiMasa);
    })
//Refresh data
    $.doTimeout( 1000, function(){
           refreshMasa();
           refreshSiparis();
            return true; // Poll.
    });

    function refreshSiparis(){
        var phpFile='content/masa.php';
        var str="";
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: phpFile,
            data: str,
            success: function(msg){
                var liste=msg.veri;
                $.each(liste,function(index,value){
                    var masa_id="#masa_"+value[0];
                    $masa=$(masa_id);
                    if(value[2]==1){
                        $masa.css('background-color','#F5A9BC');
                    }else{
                        $masa.css('background-color','#A9F5D0');
                    }
                })
            }
        })   
    }
    
    function refreshMasa(){
         var phpFile='content/ajaxMasa.php';
        var str="";
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: phpFile,
            data: str,
            success: function(msg){
                $('#zaman').html(msg.zaman[0]);
                var liste=msg.masa;
                var siparisler="Bekleyen Siparişler<hr>";
                $.each(liste,function(index,value){
                    siparisler+=" - "+value[2]+",  "+value[3]+" tane => Masa : "+value[0]+"<br />";
                })
                $('#siparisler').html(siparisler);
            }
        })   
    }
    
    function showAdisyon(hangiMasa){
        var phpFile='content/ajaxAdisyon.php';
        var str="masa="+hangiMasa;
        $('#adisyon').html("Adisyon");
        $.ajax({
            type: "POST",
            dataType: 'json',
            url: phpFile,
            data: str,
            success: function(msg){
                var zaman=msg.zaman;
                var liste=msg.adisyon;
                var adisyon="Adisyon : "+hangiMasa+" @ "+zaman+"<hr>";
                var total=0;
                $.each(liste,function(index,value){
                    var toplam=value[3]*value[4];
                    adisyon+=value[2]+" : "+value[3]+" adet @ "+value[4]+" TL ... "+toplam+" TL<br/> ";
                    total+=toplam;
                })
                adisyon+="<hr>Toplam :        "+total+" TL<br/> ";
                $('#adisyon').html(adisyon);
            }
        })   
    }

});