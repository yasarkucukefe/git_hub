<?php
date_default_timezone_set('Europe/Istanbul');
$zaman=Date('H:i:s');

include '../res/dbFunc.php';
$conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

 if (!$conn) {
        echo "Connect failed: %s\n".mysqli_connect_error();
        exit();
 }
 
 $sql="SELECT a.masa_id,a.siparis_id,b.menu_name,a.miktar FROM SIPARISLER a,MENULIST b WHERE b.auto_id=a.siparis_id AND a.durum>0 ORDER BY a.auto_id ASC";
 $stmt = mysqli_prepare($conn, $sql);
 mysqli_stmt_execute($stmt);
 
 mysqli_stmt_bind_result($stmt, $r0,$r1,$r2,$r3);
 $i=0;
 while(mysqli_stmt_fetch($stmt)){
     if($i==0) $data=Array(Array($r0,$r1,$r2,$r3));
     else array_push($data,Array($r0,$r1,$r2,$r3));$i++;
 }
 mysqli_close($conn);
 $veri['masa']=$data;
 $veri['zaman']=Array($zaman);
 
 echo json_encode($veri);



?>
