<?php
include 'res/dbFunc.php';
$conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

 if (!$conn) {
        echo "Connect failed: %s\n".mysqli_connect_error();
        exit();
 }
 
 $sql="SELECT * FROM MASALAR ORDER BY masa_isim";
 $stmt = mysqli_prepare($conn, $sql);
 mysqli_stmt_execute($stmt);
 
 mysqli_stmt_bind_result($stmt, $id,$r1,$r2,$r3);
 while(mysqli_stmt_fetch($stmt)){
     $html.="<div class='masa' id=masa_$id>".$r1."</div>";
 }
 mysqli_close($conn);
 echo $html;
 
?>
