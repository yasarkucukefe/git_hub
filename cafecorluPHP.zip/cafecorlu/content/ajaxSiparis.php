<?php //

$masa=$_POST['masa'];
$siparis=$_POST['siparis'];
$say=$_POST['say'];
$note=$_POST['note'];

include '../res/dbFunc.php';
$conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

 if (!$conn) {
        echo "Connect failed: %s\n".mysqli_connect_error();
        exit();
 }
 
 $sql="INSERT INTO SIPARISLER VALUES (null,?,?,?,?,1)";
 $stmt = mysqli_prepare($conn, $sql);
 mysqli_stmt_bind_param($stmt,'iiis',$masa,$siparis,$say,$note);
 mysqli_stmt_execute($stmt);
 if(mysqli_stmt_affected_rows($stmt)==1) $html=true;
 else $html='!! Error : ' .  mysqli_error($conn);
 if($html){
     $sql="UPDATE MASALAR SET  masa_siparis=1 WHERE auto_id=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt,'i',$masa);
    mysqli_stmt_execute($stmt);
 }
 mysqli_stmt_close($stmt);
 echo $html;
 
 

?>
