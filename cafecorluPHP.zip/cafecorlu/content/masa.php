<?php
include '../res/dbFunc.php';
$conn= mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

 if (!$conn) {
        echo "Connect failed: %s\n".mysqli_connect_error();
        exit();
 }
 
 $sql="SELECT * FROM MASALAR ORDER BY masa_isim";
 $stmt = mysqli_prepare($conn, $sql);
 mysqli_stmt_execute($stmt);
 
 mysqli_stmt_bind_result($stmt, $id,$r1,$r2,$r3);
 $i=0;
 while(mysqli_stmt_fetch($stmt)){
        if($i==0) $data=Array(Array($id,$r1,$r2,$r3));
        else array_push($data,Array($id,$r1,$r2,$r3));
        $i++;
 }
 mysqli_close($conn);
 $veri['veri']=$data;
 echo json_encode($veri);
 
?>
