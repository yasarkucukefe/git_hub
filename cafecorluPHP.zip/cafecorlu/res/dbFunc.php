<?php


$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="CAFECORLU";



function bindArray($stmtArray){
    $rArray=Array();
    //$filtre='WHERE a.auto_id>0 ';
    foreach($stmtArray as $key=>$value){
        if($value!=0) {
            array_push($rArray,$value);
            //$filtre.=" AND $key=?";
        }
    }
    return $rArray;
}

function prepareAndBind($conn,$sql,$rArray){
   $stmt = mysqli_prepare($conn, $sql);
   $fi=  count($rArray);
   if($fi==1) {mysqli_stmt_bind_param($stmt, "i", $r0);$r0=$rArray[0];}
   else if($fi==2) {mysqli_stmt_bind_param($stmt, "ii", $r0,$r1);$r0=$rArray[0];$r1=$rArray[1];}
   else if($fi==3) {mysqli_stmt_bind_param($stmt, "iii", $r0,$r1,$r2);$r0=$rArray[0];$r1=$rArray[1];$r2=$rArray[2];}
   else if($fi==4) {mysqli_stmt_bind_param($stmt, "iiii", $r0,$r1,$r2,$r3);$r0=$rArray[0];$r1=$rArray[1];$r2=$rArray[2];$r3=$rArray[3];}
   return $stmt;
}

function createNewMySQL($conn,$sql,$ba,$bs){
    $stmt=stmtPrepareBindCreate($conn,$sql,$ba,$bs);
    mysqli_stmt_execute($stmt);
    if(mysqli_stmt_affected_rows($stmt)==1) $html="OK..created.";
    else $html="!! Error :".  mysqli_error($conn);
    mysqli_stmt_close($stmt);
    return $html;        
}

function stmtPrepareBindCreate($conn,$sql,$ba,$bs){
    $stmt=  mysqli_prepare($conn, $sql);
    
    
    if(count($ba)==2) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$zaman);
    if(count($ba)==3) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$zaman);
    if(count($ba)==4) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$zaman);
    if(count($ba)==5) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$r4,$zaman);
    if(count($ba)==6) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$r4,$r5,$zaman);
    if(count($ba)==7) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$r4,$r5,$r6,$zaman);
    if(count($ba)==8) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$r4,$r5,$r6,$r7,$zaman);
    if(count($ba)==9) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$zaman);
    if(count($ba)==10) mysqli_stmt_bind_param($stmt,$bs, $auto_id,$r0,$r1,$r2,$r3,$r4,$r5,$r6,$r7,$r8,$r9,$zaman);

    $auto_id=null;
    $r0=$ba[':r0'];$r1=$ba[':r1'];$r2=$ba[':r2'];$r3=$ba[':r3'];
    $r4=$ba[':r4'];$r5=$ba[':r5'];$r6=$ba[':r6'];$r7=$ba[':r7'];$r8=$ba[':r8'];$r9=$ba[':r9'];
    $zaman=null;
    return $stmt;
}

function deleteRecordMySQL($conn,$sql,$auto_id){
     $stmt=  mysqli_prepare($conn, $sql);
     mysqli_stmt_bind_param($stmt,'i',$auto_id);
     mysqli_stmt_execute($stmt);
     if(mysqli_stmt_affected_rows($stmt)==1) $html="OK.. deleted.";
     else $html='!! Error : ' .  mysqli_error($conn);
     mysqli_stmt_close($stmt);
     return $html;
}

function executeSQL($sql,$conn){
    $html='ok';
    if (!@mysql_query($sql,$conn)) $html=mysql_error();
    return $html;
}


?>
