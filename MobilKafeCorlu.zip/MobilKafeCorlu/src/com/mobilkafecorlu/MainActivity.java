package com.mobilkafecorlu;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TableLayout.LayoutParams;

public class MainActivity extends Activity {
	final ArrayList<String> menuListe=new ArrayList<String>();
	final ArrayList<String> menuId=new ArrayList<String>();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getMasaList();
        menuList();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    private void getMasaList(){
    	final String url="http://192.168.2.15/cafecorlu/content/masa.php";
    	//
    	for(int i=1;i<=9;i++){
			  String masaIsim="masa "+Integer.toString(i);
			  masaEkle(masaIsim,i,false,50*i+20);
		  }
    	//
    	new Thread(new Runnable(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				try {
    		        HttpPost httppost = new HttpPost(url);
    		        HttpResponse response = (HttpResponse) httpclient .execute(httppost);
    		        HttpEntity resEntity = response.getEntity();  
    		       // String resp = EntityUtils.toString(resEntity,HTTP.UTF_8);
    		        String resp = EntityUtils.toString(resEntity,"ISO-8859-9");
    		        Log.i("Response from url",resp);
    		        //JSON parse part
    		        try{
    					
    					 // JSONObject mResponseObject=new JSONObject(resp);
    					  //JSONArray masaList=mResponseObject.getJSONArray("veri");
    					  	 
    				}
    				catch(Exception e)
    				{
    					Log.d("Error: ", " "+e.getMessage());
    				}
    		        
    		    } catch (UnsupportedEncodingException e) {
    		        e.printStackTrace();
    		    } catch (ClientProtocolException e) {
    		        e.printStackTrace();
    		    } catch (IOException e) {
    		        e.printStackTrace();
    		    }

				
			}
    		
    	}).start();
    	
    	
    	
    }
    
    private void menuList(){
    	final String url="http://192.168.2.15/cafecorlu/content/menu.php";
    	new Thread(new Runnable(){
    		@Override
			public void run() {
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				try {
    		        HttpPost httppost = new HttpPost(url);
    		        HttpResponse response = (HttpResponse) httpclient .execute(httppost);
    		        HttpEntity resEntity = response.getEntity();  
    		       // String resp = EntityUtils.toString(resEntity,HTTP.UTF_8);
    		        String resp = EntityUtils.toString(resEntity,"ISO-8859-9");
    		        Log.i("Response from url",resp);
    		        //JSON parse part
    		        try{
    					  JSONObject mResponseObject=new JSONObject(resp);
    					  JSONArray menuList=mResponseObject.getJSONArray("veri");
    					  for(int i=0;i<menuList.length();i++){
    						  String menuItem=menuList.getJSONArray(i).getString(1);
    						  Log.d("menu",menuItem);
    						  menuListe.add(menuItem);
    						  menuId.add(menuList.getJSONArray(i).getString(0));
    					  }	 
    				}
    				catch(Exception e)
    				{
    					Log.d("Error: ", " "+e.getMessage());
    				}
    		        
    		    } catch (UnsupportedEncodingException e) {
    		        e.printStackTrace();
    		    } catch (ClientProtocolException e) {
    		        e.printStackTrace();
    		    } catch (IOException e) {
    		        e.printStackTrace();
    		    }

				
			}
    		
    	}).start();
    }
    
    
    public void masaEkle(String isim,final int _id,boolean sol,int _top){
    	View ll=findViewById(R.id.masalar);
    	TextView grupBox=new TextView(this);
    	grupBox.setText(isim);
    	grupBox.setId(_id);
    	grupBox.setTypeface(Typeface.MONOSPACE,Typeface.BOLD);
    	grupBox.setGravity(Gravity.CENTER);
    	//Log.d("masa ekle ",isim);
    	grupBox.setBackgroundColor(Color.parseColor("#2E9AFE"));
    	RelativeLayout.LayoutParams params=new RelativeLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
    	params.topMargin=_top;
    	params.width=200;
    	params.height=30;
    	((RelativeLayout) ll).addView(grupBox,params);
    	
    	grupBox.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				TextView hangiGrup=(TextView)findViewById(arg0.getId());
				Log.d("id",(String) hangiGrup.getText());
				siparisVer(arg0.getId());
				
			}
		});
    }
  
    private void siparisVer(final int masaId){
    	AlertDialog.Builder builder = new AlertDialog.Builder(this);
	 	AlertDialog dialog;
	 	
	 	String[] menuArray=new String[menuListe.size()];
		for(int i=0;i<menuListe.size();i++){
			menuArray[i]=menuListe.get(i);
		}
	  	
	 	builder.setTitle("Menü Listesi");
		builder.setItems(menuArray, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface arg0, int which) {
				// TODO Auto-generated method stub
				
				siparisiGonder(masaId,which);
				
			}
		});
		dialog= builder.create();
	 	dialog.show();
    }

    private void siparisiGonder(final int masaId,final int hangisi){
    	Log.d("sipariş:",Integer.toString(masaId)+" =>" +menuId.get(hangisi));
    	final String url="http://192.168.2.15/cafecorlu/content/ajaxSiparis.php";
    	new Thread(new Runnable(){
    		@Override
			public void run() {
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
				
				nameValuePairs.add(new BasicNameValuePair("masa",Integer.toString(masaId)));
				nameValuePairs.add(new BasicNameValuePair("siparis",menuId.get(hangisi)));
				nameValuePairs.add(new BasicNameValuePair("say","1"));
				nameValuePairs.add(new BasicNameValuePair("note","note kısmı"));
				UrlEncodedFormEntity form;	
				try {
					form = new UrlEncodedFormEntity(nameValuePairs,"ISO-8859-9");
		            form.setContentEncoding(HTTP.UTF_8);
		            HttpPost httppost = new HttpPost(url);
		            httppost.setEntity(form);
		            HttpResponse response = (HttpResponse) httpclient .execute(httppost);
		            HttpEntity resEntity = response.getEntity();  
		            String resp = EntityUtils.toString(resEntity,HTTP.UTF_8);
		            Log.i("cevap","Server response:"+resp);
    		        
    		    } catch (UnsupportedEncodingException e) {
    		        e.printStackTrace();
    		    } catch (ClientProtocolException e) {
    		        e.printStackTrace();
    		    } catch (IOException e) {
    		        e.printStackTrace();
    		    }

				
			}
    		
    	}).start();

    	
    }
    
}
